Omnibug
==========

Omnibug is a brower plugin ease developing web metrics implementations. Each outgoing request (sent by the browser) is checked for a pattern; if a match occurs, the URL is displayed in a panel, and decoded to show the details of the request

For further details, see the main project page: http://omnibug.rosssimpson.com/


# License

See the individual LICENSE files in the browser subdirectories.

