Omnibug
==========

Omnibug, for Chrome
For more details, see the main project page: http://omnibug.rosssimpson.com/chrome.html

"O" icons courtesy of: http://www.iconarchive.com/show/bag-o-tiles-icons-by-barkerbaggies.html


# Not working

* Log to file
* Watches sidebar (only possible with an iframe?)


# @TODO

* One-click provider test page
* Docs for all new providers
* Unit tests in PhantomJS?

# Nice to haves

* Decode some (e.g. WT.dl) values


# Notes

* http://www.akravitz.com/coremetrics-vs-omniture-vs-google-analytics/

# Examples

* GUA: http://academicadvising.waldenu.edu/
* WT: http://www.spirit.com/Default.aspx
* CM: https://www.bankofamerica.com/
* OM, QUA, KRUX, NR: http://www.realestate.com.au/buy
* AT: http://www.atinternet.com/en/
* TB, QUA, FB: http://torbit.com/blog/
* KM, OPT, MRK: https://www.optimizely.com/


# License

> This work is licensed under the Creative Commons Attribution-ShareAlike 3.0 Unported License.
> To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/3.0/ or send
> a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041,
> USA.

