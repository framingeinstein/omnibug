Omnibug
=======

Omnibug, for Firefox
For the time being, see here: http://omnibug.rosssimpson.com/

# AMO Page

This add-on is pending review at AMO: https://addons.mozilla.org/en-US/firefox/addon/omnibug/


# @TODO

* Switch to provider model
* O Icon (https://developer.mozilla.org/en-US/docs/Install_Manifests#iconURL, https://developer.mozilla.org/en/docs/Building_an_Extension)

